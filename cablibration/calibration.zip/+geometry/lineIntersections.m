function pts = lineIntersections(l1,l2)

pts = cross(l1,l2);